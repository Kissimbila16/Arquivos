# speech

Uma simples aplicação em java que possui duas opções:
- Converter texto em voz;
- Converter voz em texto;
